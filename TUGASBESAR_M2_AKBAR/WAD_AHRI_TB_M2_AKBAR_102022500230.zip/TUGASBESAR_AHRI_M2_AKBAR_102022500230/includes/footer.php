<?php // Nadya Nursyifa Anantha | NIM 202432101 ?>
  <footer>© <?= date('Y') ?> Sistem Manajemen Venue Olahraga — Nadya Nursyifa Anantha (202432101)</footer>
</main>
</body>
</html>
