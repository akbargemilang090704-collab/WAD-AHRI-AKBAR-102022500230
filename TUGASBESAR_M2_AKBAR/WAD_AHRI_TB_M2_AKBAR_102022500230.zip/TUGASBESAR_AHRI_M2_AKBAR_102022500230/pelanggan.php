<?php
require_once 'includes/auth.php';
require_once 'config/database.php';
require_login();

$level_opsi = ['Basic', 'Gold', 'VIP'];
$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (($_POST['do'] ?? '') === 'delete') {
        $pdo->prepare('DELETE FROM pelanggan WHERE id = ?')->execute([(int)$_POST['id']]);
        flash_set('success', 'Data pelanggan berhasil dihapus.');
        header('Location: pelanggan.php'); exit;
    }

    $d = [
        'nama'         => trim($_POST['nama'] ?? ''),
        'email'        => trim($_POST['email'] ?? ''),
        'telepon'      => trim($_POST['telepon'] ?? ''),
        'alamat'       => trim($_POST['alamat'] ?? ''),
        'level_member' => $_POST['level_member'] ?? '',
    ];
    $id = (int)($_POST['id'] ?? 0);

    if ($d['nama'] === '') $errors[] = 'Nama wajib diisi.';
    if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
    if (!preg_match('/^[0-9+\-\s]{8,20}$/', $d['telepon'])) $errors[] = 'Nomor telepon tidak valid (8–20 digit).';
    if (!in_array($d['level_member'], $level_opsi, true)) $errors[] = 'Level member tidak valid.';

    if (!$errors) {
        $cek = $pdo->prepare('SELECT COUNT(*) FROM pelanggan WHERE email = ? AND id <> ?');
        $cek->execute([$d['email'], $id]);
        if ($cek->fetchColumn() > 0) $errors[] = 'Email sudah terdaftar.';
    }

    if (!$errors) {
        if ($id) {
            $pdo->prepare('UPDATE pelanggan SET nama=:nama, email=:email, telepon=:telepon, alamat=:alamat,
                level_member=:level_member WHERE id=:id')->execute($d + ['id' => $id]);
            flash_set('success', 'Data pelanggan berhasil diperbarui.');
        } else {
            $pdo->prepare('INSERT INTO pelanggan (nama,email,telepon,alamat,level_member)
                VALUES (:nama,:email,:telepon,:alamat,:level_member)')->execute($d);
            flash_set('success', 'Pelanggan baru berhasil ditambahkan.');
        }
        header('Location: pelanggan.php'); exit;
    }
    $action = $id ? 'edit' : 'create';
    $row = $d;
}

$page_title = 'Modul Pelanggan & Member';
require 'includes/header.php';

if ($action === 'create' || $action === 'edit'):
    if (!isset($row)) {
        $row = ['nama'=>'','email'=>'','telepon'=>'','alamat'=>'','level_member'=>'Basic'];
        if ($action === 'edit') {
            $s = $pdo->prepare('SELECT * FROM pelanggan WHERE id = ?'); $s->execute([$id]);
            $row = $s->fetch() ?: die('Data tidak ditemukan.');
        }
    }
?>
<div class="panel">
  <h2><?= $action === 'edit' ? 'Edit Pelanggan' : 'Tambah Pelanggan' ?></h2>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $id ?>">
    <div><label>Nama Lengkap</label><input name="nama" value="<?= e($row['nama']) ?>" required></div>
    <div><label>Email</label><input type="email" name="email" value="<?= e($row['email']) ?>" required></div>
    <div><label>No. Telepon</label><input name="telepon" value="<?= e($row['telepon']) ?>" required></div>
    <div><label>Level Member</label>
      <select name="level_member">
        <?php foreach ($level_opsi as $o): ?><option <?= $row['level_member']===$o?'selected':'' ?>><?= e($o) ?></option><?php endforeach; ?>
      </select></div>
    <div class="full"><label>Alamat</label><textarea name="alamat" rows="3"><?= e($row['alamat']) ?></textarea></div>
    <div class="actions full">
      <button class="btn primary">Simpan</button>
      <a class="btn" href="pelanggan.php">Batal</a>
    </div>
  </form>
</div>
<?php
else:
    $q = trim($_GET['q'] ?? '');
    $lv = $_GET['level'] ?? '';
    $sql = 'SELECT * FROM pelanggan WHERE (nama LIKE :q OR email LIKE :q OR telepon LIKE :q)';
    $p = ['q' => "%$q%"];
    if (in_array($lv, $level_opsi, true)) { $sql .= ' AND level_member = :lv'; $p['lv'] = $lv; }
    $s = $pdo->prepare($sql . ' ORDER BY id DESC'); $s->execute($p);
    $rows = $s->fetchAll();
?>
<div class="toolbar">
  <form method="get" class="search">
    <input name="q" value="<?= e($q) ?>" placeholder="Cari nama / email / telepon...">
    <select name="level"><option value="">Semua level</option>
      <?php foreach ($level_opsi as $o): ?><option <?= $lv===$o?'selected':'' ?>><?= e($o) ?></option><?php endforeach; ?>
    </select>
    <button class="btn">Cari</button>
  </form>
  <a class="btn primary" href="?action=create">+ Tambah Pelanggan</a>
</div>
<div class="panel table-wrap">
<table>
  <thead><tr><th>No</th><th>Nama</th><th>Email</th><th>Telepon</th><th>Level</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="6" class="empty">Belum ada data.</td></tr><?php endif; ?>
  <?php foreach ($rows as $i => $r): ?>
    <tr>
      <td><?= $i + 1 ?></td><td><?= e($r['nama']) ?></td><td><?= e($r['email']) ?></td><td><?= e($r['telepon']) ?></td>
      <td><span class="badge lvl-<?= strtolower($r['level_member']) ?>"><?= e($r['level_member']) ?></span></td>
      <td class="row-actions">
        <a class="btn sm" href="?action=edit&id=<?= $r['id'] ?>">Edit</a>
        <form method="post" onsubmit="return confirm('Hapus pelanggan ini?')">
          <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button class="btn sm danger">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; require 'includes/footer.php'; ?>
