<?php // Nadya Nursyifa Anantha | NIM 202432101
$current = basename($_SERVER['PHP_SELF']);
$menu = [
  'index.php'     => 'Dashboard',
  'lapangan.php'  => 'Lapangan & Area',
  'alat.php'      => 'Rental Alat',
  'pelanggan.php' => 'Pelanggan & Member',
  'instruktur.php'=> 'Instruktur & Coach',
];
$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title ?? 'Venue Olahraga') ?> | Sistem Venue Olahraga</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<aside class="sidebar">
  <div class="brand">🏟️ Venue<span>Sport</span></div>
  <nav>
    <?php foreach ($menu as $file => $label): ?>
      <a href="<?= $file ?>" class="<?= $current === $file ? 'active' : '' ?>"><?= e($label) ?></a>
    <?php endforeach; ?>
  </nav>
  <div class="user">
    <small>Masuk sebagai</small>
    <strong><?= e($_SESSION['user']['nama']) ?></strong>
    <a href="logout.php" class="logout">Keluar</a>
  </div>
</aside>
<main class="content">
  <h1><?= e($page_title ?? '') ?></h1>
  <?php if ($flash): ?>
    <div class="alert <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
  <?php endif; ?>
