<?php

require_once 'includes/auth.php';
require_once 'config/database.php';
require_login();
$page_title = 'Dashboard';

$stat = [];
foreach (['lapangan' => 'Lapangan', 'alat' => 'Alat Sewa', 'pelanggan' => 'Pelanggan', 'instruktur' => 'Instruktur'] as $t => $label) {
    $stat[$label] = [$t, $pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn()];
}
require 'includes/header.php';
?>
<p class="muted">Selamat datang! Ini ringkasan data venue kamu.</p>
<div class="cards">
  <?php foreach ($stat as $label => [$t, $n]): ?>
    <a class="card" href="<?= $t ?>.php"><span><?= e($label) ?></span><strong><?= (int)$n ?></strong></a>
  <?php endforeach; ?>
</div>
<?php require 'includes/footer.php'; ?>
