<?php
require_once 'includes/auth.php';
require_once 'config/database.php';

if (!empty($_SESSION['user'])) { header('Location: index.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute([trim($_POST['username'] ?? '')]);
    $user = $stmt->fetch();
    if ($user && password_verify($_POST['password'] ?? '', $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => $user['id'], 'nama' => $user['nama']];
        header('Location: index.php'); exit;
    }
    $error = 'Username atau password salah.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login | Sistem Venue Olahraga</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
  <form method="post" class="login-box">
    <div class="brand">🏟️ Venue<span>Sport</span></div>
    <p class="muted">Silakan masuk untuk mengelola venue.</p>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <?= csrf_field() ?>
    <label>Username</label><input name="username" required autofocus>
    <label>Password</label><input type="password" name="password" required>
    <button class="btn primary block">Masuk</button>
    <p class="muted small">Demo: admin / password</p>
  </form>
</body>
</html>
