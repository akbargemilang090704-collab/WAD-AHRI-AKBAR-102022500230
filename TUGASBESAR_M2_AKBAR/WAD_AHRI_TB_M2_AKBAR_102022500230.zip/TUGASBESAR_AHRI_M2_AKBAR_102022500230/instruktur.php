<?php
// Modul D: Instruktur & Coach (AKBAR)
require_once 'includes/auth.php';
require_once 'config/database.php';
require_login();

$keahlian_opsi = ['Futsal', 'Badminton', 'Basket', 'Voli', 'Tenis', 'Renang', 'Mini Soccer'];
$status_opsi   = ['Aktif', 'Nonaktif'];
$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (($_POST['do'] ?? '') === 'delete') {
        $pdo->prepare('DELETE FROM instruktur WHERE id = ?')->execute([(int)$_POST['id']]);
        flash_set('success', 'Data instruktur berhasil dihapus.');
        header('Location: instruktur.php'); exit;
    }

    $d = [
        'nama'       => trim($_POST['nama'] ?? ''),
        'no_lisensi' => strtoupper(trim($_POST['no_lisensi'] ?? '')),
        'keahlian'   => $_POST['keahlian'] ?? '',
        'telepon'    => trim($_POST['telepon'] ?? ''),
        'status'     => $_POST['status'] ?? '',
    ];
    $id = (int)($_POST['id'] ?? 0);

    if ($d['nama'] === '')       $errors[] = 'Nama wajib diisi.';
    if ($d['no_lisensi'] === '') $errors[] = 'Nomor lisensi wajib diisi.';
    if (!in_array($d['keahlian'], $keahlian_opsi, true)) $errors[] = 'Keahlian tidak valid.';
    if (!preg_match('/^[0-9+\-\s]{8,20}$/', $d['telepon'])) $errors[] = 'Nomor telepon tidak valid (8–20 digit).';
    if (!in_array($d['status'], $status_opsi, true))     $errors[] = 'Status tidak valid.';

    if (!$errors) {
        $cek = $pdo->prepare('SELECT COUNT(*) FROM instruktur WHERE no_lisensi = ? AND id <> ?');
        $cek->execute([$d['no_lisensi'], $id]);
        if ($cek->fetchColumn() > 0) $errors[] = 'Nomor lisensi sudah terdaftar.';
    }

    if (!$errors) {
        if ($id) {
            $pdo->prepare('UPDATE instruktur SET nama=:nama, no_lisensi=:no_lisensi, keahlian=:keahlian,
                telepon=:telepon, status=:status WHERE id=:id')->execute($d + ['id' => $id]);
            flash_set('success', 'Data instruktur berhasil diperbarui.');
        } else {
            $pdo->prepare('INSERT INTO instruktur (nama,no_lisensi,keahlian,telepon,status)
                VALUES (:nama,:no_lisensi,:keahlian,:telepon,:status)')->execute($d);
            flash_set('success', 'Instruktur baru berhasil ditambahkan.');
        }
        header('Location: instruktur.php'); exit;
    }
    $action = $id ? 'edit' : 'create';
    $row = $d;
}

$page_title = 'Modul Instruktur & Coach';
require 'includes/header.php';

if ($action === 'create' || $action === 'edit'):
    if (!isset($row)) {
        $row = ['nama'=>'','no_lisensi'=>'','keahlian'=>'','telepon'=>'','status'=>'Aktif'];
        if ($action === 'edit') {
            $s = $pdo->prepare('SELECT * FROM instruktur WHERE id = ?'); $s->execute([$id]);
            $row = $s->fetch() ?: die('Data tidak ditemukan.');
        }
    }
?>
<div class="panel">
  <h2><?= $action === 'edit' ? 'Edit Instruktur' : 'Tambah Instruktur' ?></h2>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $id ?>">
    <div><label>Nama Instruktur</label><input name="nama" value="<?= e($row['nama']) ?>" required></div>
    <div><label>Nomor Lisensi</label><input name="no_lisensi" value="<?= e($row['no_lisensi']) ?>" placeholder="LIC-FUT-0099" required></div>
    <div><label>Keahlian Cabang Olahraga</label>
      <select name="keahlian" required><option value="">-- pilih --</option>
        <?php foreach ($keahlian_opsi as $o): ?><option <?= $row['keahlian']===$o?'selected':'' ?>><?= e($o) ?></option><?php endforeach; ?>
      </select></div>
    <div><label>No. Telepon</label><input name="telepon" value="<?= e($row['telepon']) ?>" required></div>
    <div><label>Status</label>
      <select name="status">
        <?php foreach ($status_opsi as $o): ?><option <?= $row['status']===$o?'selected':'' ?>><?= e($o) ?></option><?php endforeach; ?>
      </select></div>
    <div class="actions full">
      <button class="btn primary">Simpan</button>
      <a class="btn" href="instruktur.php">Batal</a>
    </div>
  </form>
</div>
<?php
else:
    $q = trim($_GET['q'] ?? '');
    $s = $pdo->prepare('SELECT * FROM instruktur WHERE nama LIKE :q OR no_lisensi LIKE :q OR keahlian LIKE :q ORDER BY id DESC');
    $s->execute(['q' => "%$q%"]);
    $rows = $s->fetchAll();
?>
<div class="toolbar">
  <form method="get" class="search"><input name="q" value="<?= e($q) ?>" placeholder="Cari nama / lisensi / keahlian..."><button class="btn">Cari</button></form>
  <a class="btn primary" href="?action=create">+ Tambah Instruktur</a>
</div>
<div class="panel table-wrap">
<table>
  <thead><tr><th>No</th><th>Nama</th><th>No. Lisensi</th><th>Keahlian</th><th>Telepon</th><th>Status</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="7" class="empty">Belum ada data.</td></tr><?php endif; ?>
  <?php foreach ($rows as $i => $r): ?>
    <tr>
      <td><?= $i + 1 ?></td><td><?= e($r['nama']) ?></td><td><?= e($r['no_lisensi']) ?></td>
      <td><?= e($r['keahlian']) ?></td><td><?= e($r['telepon']) ?></td>
      <td><span class="badge <?= $r['status']==='Aktif'?'ok':'bad' ?>"><?= e($r['status']) ?></span></td>
      <td class="row-actions">
        <a class="btn sm" href="?action=edit&id=<?= $r['id'] ?>">Edit</a>
        <form method="post" onsubmit="return confirm('Hapus instruktur ini?')">
          <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button class="btn sm danger">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; require 'includes/footer.php'; ?>
