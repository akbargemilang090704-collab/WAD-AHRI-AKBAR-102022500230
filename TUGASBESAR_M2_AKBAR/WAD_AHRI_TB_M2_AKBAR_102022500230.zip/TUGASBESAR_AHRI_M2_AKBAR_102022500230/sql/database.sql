CREATE DATABASE IF NOT EXISTS venue_olahraga CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE venue_olahraga;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  nama VARCHAR(100) NOT NULL
);


CREATE TABLE IF NOT EXISTS lapangan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  jenis_olahraga VARCHAR(50) NOT NULL,
  jenis_permukaan VARCHAR(50) NOT NULL,
  ukuran VARCHAR(50) NOT NULL,
  status_fisik ENUM('Baik','Perlu Perawatan','Rusak') NOT NULL DEFAULT 'Baik',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS alat (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  kategori VARCHAR(50) NOT NULL,
  kondisi ENUM('Baik','Cukup','Rusak') NOT NULL DEFAULT 'Baik',
  stok INT NOT NULL DEFAULT 0,
  tarif_sewa DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS pelanggan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  telepon VARCHAR(20) NOT NULL,
  alamat TEXT,
  level_member ENUM('Basic','Gold','VIP') NOT NULL DEFAULT 'Basic',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS instruktur (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  no_lisensi VARCHAR(50) NOT NULL UNIQUE,
  keahlian VARCHAR(50) NOT NULL,
  telepon VARCHAR(20) NOT NULL,
  status ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO users (username, password, nama) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator');

INSERT INTO lapangan (kode,nama,jenis_olahraga,jenis_permukaan,ukuran,status_fisik) VALUES
('LP-001','Lapangan Futsal A','Futsal','Vinyl','25 x 15 m','Baik'),
('LP-002','Lapangan Badminton 1','Badminton','Karpet Karet','13,4 x 6,1 m','Baik'),
('LP-003','Lapangan Mini Soccer','Mini Soccer','Rumput Sintetis','40 x 20 m','Perlu Perawatan');

INSERT INTO alat (kode,nama,kategori,kondisi,stok,tarif_sewa) VALUES
('AL-001','Raket Badminton Yonex','Raket','Baik',10,15000),
('AL-002','Bola Futsal Molten','Bola','Baik',6,10000),
('AL-003','Rompi Tim (set 5)','Rompi','Cukup',8,5000);

INSERT INTO pelanggan (nama,email,telepon,alamat,level_member) VALUES
('Budi Santoso','budi@mail.com','081234567890','Jakarta Timur','Gold'),
('Siti Rahma','siti@mail.com','082198765432','Jakarta Barat','VIP'),
('Andi Wijaya','andi@mail.com','085611223344','Depok','Basic');

INSERT INTO instruktur (nama,no_lisensi,keahlian,telepon,status) VALUES
('Coach Rendra','LIC-FUT-0012','Futsal','081300000001','Aktif'),
('Coach Maya','LIC-BAD-0034','Badminton','081300000002','Aktif');
