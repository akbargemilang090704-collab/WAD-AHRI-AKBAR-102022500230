<?php

require_once 'includes/auth.php';
require_once 'config/database.php';
require_login();

$kategori_opsi = ['Raket', 'Bola', 'Rompi', 'Sepatu', 'Net', 'Lainnya'];
$kondisi_opsi  = ['Baik', 'Cukup', 'Rusak'];

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (($_POST['do'] ?? '') === 'delete') {
        $pdo->prepare('DELETE FROM alat WHERE id = ?')->execute([(int)$_POST['id']]);
        flash_set('success', 'Data alat berhasil dihapus.');
        header('Location: alat.php'); exit;
    }

    $d = [
        'kode'       => strtoupper(trim($_POST['kode'] ?? '')),
        'nama'       => trim($_POST['nama'] ?? ''),
        'kategori'   => $_POST['kategori'] ?? '',
        'kondisi'    => $_POST['kondisi'] ?? '',
        'stok'       => $_POST['stok'] ?? '',
        'tarif_sewa' => $_POST['tarif_sewa'] ?? '',
    ];
    $id = (int)($_POST['id'] ?? 0);

    if ($d['kode'] === '') $errors[] = 'Kode wajib diisi.';
    if ($d['nama'] === '') $errors[] = 'Nama alat wajib diisi.';
    if (!in_array($d['kategori'], $kategori_opsi, true)) $errors[] = 'Kategori tidak valid.';
    if (!in_array($d['kondisi'], $kondisi_opsi, true))   $errors[] = 'Kondisi tidak valid.';
    if (!ctype_digit((string)$d['stok']))                $errors[] = 'Stok harus angka bulat ≥ 0.';
    if (!is_numeric($d['tarif_sewa']) || $d['tarif_sewa'] < 0) $errors[] = 'Tarif sewa harus angka ≥ 0.';

    if (!$errors) {
        $cek = $pdo->prepare('SELECT COUNT(*) FROM alat WHERE kode = ? AND id <> ?');
        $cek->execute([$d['kode'], $id]);
        if ($cek->fetchColumn() > 0) $errors[] = 'Kode sudah dipakai alat lain.';
    }

    if (!$errors) {
        if ($id) {
            $pdo->prepare('UPDATE alat SET kode=:kode, nama=:nama, kategori=:kategori, kondisi=:kondisi,
                stok=:stok, tarif_sewa=:tarif_sewa WHERE id=:id')->execute($d + ['id' => $id]);
            flash_set('success', 'Data alat berhasil diperbarui.');
        } else {
            $pdo->prepare('INSERT INTO alat (kode,nama,kategori,kondisi,stok,tarif_sewa)
                VALUES (:kode,:nama,:kategori,:kondisi,:stok,:tarif_sewa)')->execute($d);
            flash_set('success', 'Alat baru berhasil ditambahkan.');
        }
        header('Location: alat.php'); exit;
    }
    $action = $id ? 'edit' : 'create';
    $row = $d;
}

$page_title = 'Modul Rental Alat Olahraga';
require 'includes/header.php';

if ($action === 'create' || $action === 'edit'):
    if (!isset($row)) {
        $row = ['kode'=>'','nama'=>'','kategori'=>'','kondisi'=>'Baik','stok'=>0,'tarif_sewa'=>0];
        if ($action === 'edit') {
            $s = $pdo->prepare('SELECT * FROM alat WHERE id = ?'); $s->execute([$id]);
            $row = $s->fetch() ?: die('Data tidak ditemukan.');
        }
    }
?>
<div class="panel">
  <h2><?= $action === 'edit' ? 'Edit Alat' : 'Tambah Alat' ?></h2>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $id ?>">
    <div><label>Kode</label><input name="kode" value="<?= e($row['kode']) ?>" placeholder="AL-004" required></div>
    <div><label>Nama Alat</label><input name="nama" value="<?= e($row['nama']) ?>" required></div>
    <div><label>Kategori</label>
      <select name="kategori" required><option value="">-- pilih --</option>
        <?php foreach ($kategori_opsi as $o): ?><option <?= $row['kategori']===$o?'selected':'' ?>><?= e($o) ?></option><?php endforeach; ?>
      </select></div>
    <div><label>Kondisi</label>
      <select name="kondisi">
        <?php foreach ($kondisi_opsi as $o): ?><option <?= $row['kondisi']===$o?'selected':'' ?>><?= e($o) ?></option><?php endforeach; ?>
      </select></div>
    <div><label>Stok</label><input type="number" min="0" name="stok" value="<?= e($row['stok']) ?>" required></div>
    <div><label>Tarif Sewa (Rp / sesi)</label><input type="number" min="0" step="500" name="tarif_sewa" value="<?= e($row['tarif_sewa']) ?>" required></div>
    <div class="actions full">
      <button class="btn primary">Simpan</button>
      <a class="btn" href="alat.php">Batal</a>
    </div>
  </form>
</div>
<?php
else:
    $q = trim($_GET['q'] ?? '');
    $s = $pdo->prepare('SELECT * FROM alat WHERE nama LIKE :q OR kode LIKE :q OR kategori LIKE :q ORDER BY id DESC');
    $s->execute(['q' => "%$q%"]);
    $rows = $s->fetchAll();
?>
<div class="toolbar">
  <form method="get" class="search"><input name="q" value="<?= e($q) ?>" placeholder="Cari kode / nama / kategori..."><button class="btn">Cari</button></form>
  <a class="btn primary" href="?action=create">+ Tambah Alat</a>
</div>
<div class="panel table-wrap">
<table>
  <thead><tr><th>No</th><th>Kode</th><th>Nama</th><th>Kategori</th><th>Kondisi</th><th>Stok</th><th>Tarif Sewa</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="8" class="empty">Belum ada data.</td></tr><?php endif; ?>
  <?php foreach ($rows as $i => $r): ?>
    <tr>
      <td><?= $i + 1 ?></td><td><?= e($r['kode']) ?></td><td><?= e($r['nama']) ?></td><td><?= e($r['kategori']) ?></td>
      <td><span class="badge <?= $r['kondisi']==='Baik'?'ok':($r['kondisi']==='Rusak'?'bad':'warn') ?>"><?= e($r['kondisi']) ?></span></td>
      <td><?= (int)$r['stok'] ?></td>
      <td>Rp <?= number_format($r['tarif_sewa'], 0, ',', '.') ?></td>
      <td class="row-actions">
        <a class="btn sm" href="?action=edit&id=<?= $r['id'] ?>">Edit</a>
        <form method="post" onsubmit="return confirm('Hapus alat ini?')">
          <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button class="btn sm danger">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; require 'includes/footer.php'; ?>
