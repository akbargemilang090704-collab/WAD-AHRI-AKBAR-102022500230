<?php
session_start();
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json; charset=utf-8');

function out($code, $data) { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); exit; }

if (empty($_SESSION['user'])) out(401, ['error' => 'Belum login. Silakan login lewat login.php dulu.']);

// Whitelist tabel & kolom yang boleh diubah
$resources = [
    'lapangan'   => ['kode','nama','jenis_olahraga','jenis_permukaan','ukuran','status_fisik'],
    'alat'       => ['kode','nama','kategori','kondisi','stok','tarif_sewa'],
    'pelanggan'  => ['nama','email','telepon','alamat','level_member'],
    'instruktur' => ['nama','no_lisensi','keahlian','telepon','status'],
];

$res = $_GET['resource'] ?? '';
if (!isset($resources[$res])) out(404, ['error' => 'Resource tidak ditemukan.', 'tersedia' => array_keys($resources)]);
$cols   = $resources[$res];
$id     = (int)($_GET['id'] ?? 0);
$method = $_SERVER['REQUEST_METHOD'];
$body   = json_decode(file_get_contents('php://input'), true) ?? [];

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                $s = $pdo->prepare("SELECT * FROM $res WHERE id = ?"); $s->execute([$id]);
                $r = $s->fetch();
                $r ? out(200, $r) : out(404, ['error' => 'Data tidak ditemukan.']);
            }
            out(200, $pdo->query("SELECT * FROM $res ORDER BY id DESC")->fetchAll());

        case 'POST':
            $data = array_intersect_key($body, array_flip($cols));
            if (count($data) !== count($cols)) out(422, ['error' => 'Field wajib: ' . implode(', ', $cols)]);
            $sql = "INSERT INTO $res (" . implode(',', array_keys($data)) . ') VALUES (:' . implode(',:', array_keys($data)) . ')';
            $pdo->prepare($sql)->execute($data);
            out(201, ['message' => 'Data dibuat.', 'id' => (int)$pdo->lastInsertId()]);

        case 'PUT':
            if (!$id) out(400, ['error' => 'Parameter id wajib.']);
            $data = array_intersect_key($body, array_flip($cols));
            if (!$data) out(422, ['error' => 'Tidak ada field valid untuk diubah.']);
            $set = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($data)));
            $st = $pdo->prepare("UPDATE $res SET $set WHERE id = :id");
            $st->execute($data + ['id' => $id]);
            out(200, ['message' => 'Data diperbarui.']);

        case 'DELETE':
            if (!$id) out(400, ['error' => 'Parameter id wajib.']);
            $st = $pdo->prepare("DELETE FROM $res WHERE id = ?"); $st->execute([$id]);
            $st->rowCount() ? out(200, ['message' => 'Data dihapus.']) : out(404, ['error' => 'Data tidak ditemukan.']);

        default:
            out(405, ['error' => 'Method tidak diizinkan.']);
    }
} catch (PDOException $e) {
    out(400, ['error' => 'Gagal memproses data (cek data duplikat / nilai enum).']);
}
